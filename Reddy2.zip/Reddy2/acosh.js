require('../../modules/es6.math.acosh');
module.exports = require('../../modules/_core').Math.acosh;