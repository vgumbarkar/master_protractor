require('../modules/es7.string.trim-left');
require('../modules/es7.string.trim-right');
require('../modules/es7.string.match-all');
require('../modules/es7.symbol.observable');
module.exports = require('./2');
