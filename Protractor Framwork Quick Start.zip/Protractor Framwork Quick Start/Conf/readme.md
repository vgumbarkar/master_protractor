# Conf

This folder contains all Protractor configuration related stuff.