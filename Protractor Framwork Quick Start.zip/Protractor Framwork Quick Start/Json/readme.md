# JSON Folder

This folder contains all Object Repository for  Partner Portal.

1) PartnerPortalOR ==> Object repo of all the elements on partnerPortal pages will be stored on this json.