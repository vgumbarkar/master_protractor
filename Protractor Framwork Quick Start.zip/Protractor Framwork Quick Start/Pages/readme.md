# pages

This folder contains all page related input that is needed for a test spec. Pages in this folder are referenced in spec files (see specs folder) in which this page related input is injected.

This has a lot of advantages. For more information check pageOjects (http://www.protractortest.org/#/page-objects) in protractor documentation.