# specs

This folder contains all tests specs for the Eneco platform. A test spec can contain a complete userflow or a part of it.